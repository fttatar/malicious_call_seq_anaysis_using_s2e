##description of API_dataset.csv

1st column : malware’s class (analyzed by Kaspersky AntiVirus)
2nd column : sha256 hashed value of malware 
from 3rd column : API call sequences