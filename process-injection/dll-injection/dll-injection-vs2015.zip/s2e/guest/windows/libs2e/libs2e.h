#ifndef __LIBS2E_H__
#define __LIBS2E_H__

#define USER_APP
#include <s2e/s2e.h>

#endif