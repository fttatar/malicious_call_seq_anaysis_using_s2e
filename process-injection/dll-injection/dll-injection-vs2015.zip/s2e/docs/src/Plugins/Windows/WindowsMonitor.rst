==============
WindowsMonitor
==============

The ``WindowsMonitor`` plugin implements the detection of module and process loads/unloads on the Windows operating
system. It can be referred to as ``OSMonitor`` by other plugins. The plugin catches the invocation of specific kernel
functions to detect these events.

Options
-------
